<?php

if (! defined('ABSPATH')) {
    exit;
}

$data = wp_parse_args(
    $args,
    [
        'id'                    => '',
        'class'                 => '',
        'class_container'       => '',
        'title'                 => '',
        'description'           => '',
        'image_id'              => 0,
        'secondary_image_id'    => 0,
        'image_size'            => 'full',
        'secondary_image_size'  => 'full',
        'lazyload'              => false,
        'enable_container'      => false,
        'counters'              => [],
        'primary_button_text'   => '',
        'primary_button_link'   => '',
        'secondary_button_text' => '',
        'secondary_button_link' => '',
    ]
);

$_class = 'for-school';
$_class .= ! empty($data['class']) ? esc_attr(' ' . $data['class']) : '';

$_class_container = 'container';
$_class_container .= ! empty($data['class_container']) ? esc_attr(' ' . $data['class_container']) : '';

$has_primary_button = ! empty($data['primary_button_text']) && ! empty($data['primary_button_link']);
$has_secondary_button = ! empty($data['secondary_button_text']) && ! empty($data['secondary_button_link']);
$has_buttons = $has_primary_button || $has_secondary_button;
$counters = is_array($data['counters']) ? array_filter($data['counters']) : [];
?>

<section class="<?php echo esc_attr($_class); ?>" <?php if (! empty($data['id'])) : ?> id="<?php echo esc_attr(sanitize_file_name(strtolower($data['id']))); ?>" <?php endif; ?>>
    <?php
    if (is_front_page()) {
        get_template_part(
            'templates/components/image-light',
            null,
            [
                'class' => 'desktop',
                'side' => 'left',
                'src' => TWMP_IMG_URI . '/left-light-1.png',
                'alt' => $data && !empty($data['title']) ? $data['title'] : '',
                'width' => 1120,
                'height' => 1069,
            ]
        );
    } else {
        get_template_part(
            'templates/components/image-light',
            null,
            [
                'class' => 'page-for-school__image-light',
                'side' => 'left',
                'src' => TWMP_IMG_URI . '/left-light-2.png',
                'alt' => $data && !empty($data['title']) ? $data['title'] : '',
                'width' => 1120,
                'height' => 1069,
            ]
        );

        get_template_part(
            'templates/components/image-light',
            null,
            [
                'side' => 'right',
                'src' => TWMP_IMG_URI . '/right-light-1.png',
                'alt' => $data && !empty($data['title']) ? $data['title'] : '',
                'width' => 1081,
                'height' => 1069,
            ]
        );
    }
    ?>

    <?php if ($data['enable_container']) : ?>
        <div class="<?php echo esc_attr($_class_container); ?>">
        <?php endif; ?>

        <div class="for-school__grid">
            <div class="for-school__content">
                <?php
                get_template_part(
                    'templates/components/image-light',
                    null,
                    [
                        'class' => 'mobile',
                        'side' => 'left',
                        'src' => TWMP_IMG_URI . '/about-light.png',
                        'alt' => $data && !empty($data['title']) ? $data['title'] : '',
                        'width' => 1018,
                        'height' => 508,
                    ]
                );
                ?>
                <?php
                get_template_part('templates/components/heading', null, [
                    'title_class' => 'for-school__title desktop',
                    'description_class' => 'for-school__description',
                    'class' => 'for-school__header flex-column',
                    'title' => $data && !empty($data['title']) ? $data['title'] : '',
                    'description' => $data && !empty($data['description']) ? $data['description'] : '',
                ]);
                ?>

                <?php if (! empty($counters)) : ?>
                    <div class="for-school__stats" data-block="about-couter" role="list">
                        <?php foreach ($counters as $counter) : ?>
                            <?php
                            $value = isset($counter['value']) ? trim((string) $counter['value']) : '';
                            $label = isset($counter['label']) ? trim((string) $counter['label']) : '';

                            if ('' === $value && '' === $label) {
                                continue;
                            }
                            ?>
                            <div class="for-school__stat" role="listitem">
                                <?php if ('' !== $value) : ?>
                                    <div class="for-school__stat-value"><?php echo esc_html($value); ?></div>
                                <?php endif; ?>
                                <?php if ('' !== $label) : ?>
                                    <div class="for-school__stat-label"><?php echo esc_html($label); ?></div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if ($has_buttons) : ?>
                    <div class="for-school__actions">
                        <?php
                        if ($has_primary_button) {
                            get_template_part(
                                'templates/components/button',
                                null,
                                [
                                    'class'              => 'for-school__button for-school__button--primary bg-primary-500 text-system-white typo-system-button button-large',
                                    'button_text'        => $data['primary_button_text'],
                                    'button_url'         => $data['primary_button_link'],
                                    'button_link_target' => '_self',
                                ]
                            );
                        }

                        if ($has_secondary_button) {
                            get_template_part(
                                'templates/components/button',
                                null,
                                [
                                    'class'              => 'for-school__button for-school__button--secondary text-system-white typo-system-button button-large',
                                    'button_text'        => $data['secondary_button_text'],
                                    'button_url'         => $data['secondary_button_link'],
                                    'button_link_target' => '_self',
                                ]
                            );
                        }
                        ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="for-school__media">
                <div class="section-shape for-school__shape for-school__shape--square" aria-hidden="true"></div>
                <div class="section-shape for-school__shape for-school__shape--circle" aria-hidden="true"></div>
                <?php
                get_template_part('templates/components/heading', null, [
                    'title_class' => 'for-school__title mobile',
                    'description_class' => 'for-school__description',
                    'class' => 'for-school__header flex-column',
                    'title' => $data && !empty($data['title']) ? $data['title'] : '',
                    'description' => '',
                ]);
                ?>
                <div class="for-school__media-accent" aria-hidden="true"></div>

                <?php if (! empty($data['image_id'])) : ?>
                    <div class="for-school__media-primary">
                        <?php
                        get_template_part(
                            'templates/components/image',
                            null,
                            [
                                'image_id'    => $data['image_id'],
                                'image_size'  => $data['image_size'],
                                'lazyload'    => $data['lazyload'],
                                'class'       => 'for-school__image-wrap for-school__image-wrap--primary image--cover image--default',
                                'image_class' => 'for-school__image for-school__image--primary',
                                'alt'         => $data['title'],
                            ]
                        );
                        ?>
                    </div>
                <?php endif; ?>

                <?php if (! empty($data['secondary_image_id'])) : ?>
                    <div class="for-school__media-secondary">
                        <?php
                        get_template_part(
                            'templates/components/image',
                            null,
                            [
                                'image_id'    => $data['secondary_image_id'],
                                'image_size'  => $data['secondary_image_size'],
                                'lazyload'    => $data['lazyload'],
                                'class'       => 'for-school__image-wrap for-school__image-wrap--secondary image--cover image--default',
                                'image_class' => 'for-school__image for-school__image--secondary',
                                'alt'         => $data['title'],
                            ]
                        );
                        ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($data['enable_container']) : ?>
        </div>
    <?php endif; ?>
</section>